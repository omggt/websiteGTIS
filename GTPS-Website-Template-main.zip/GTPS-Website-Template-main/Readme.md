# GTPS Website Template

## 📄 Description
This is Sample GTPS Website template for your GTPS Server. 

**Note:** This is free to use
## 🌏 Sample Site
- Sample Site: [Click Here](https://gtps-website-template.ajdskjdkasak19.repl.co/)

## 🔧 Tools
- HTML
- CSS
- JS
- Google Font
- Font Awesome

## 📎 Setup / Usage
1. Download this project, switch `code -> download zip` and extract the rar to file and move that's file to 1 folder or to your folder

<img src="https://cdn.discordapp.com/attachments/777509514890313758/792403274007314492/unknown.png" alt="iniGambar">

2. Go to file Called `config.js` for configurate the website whatever you want

3. Host the website in another web hosting :) ( `if you want to make your website public` )

## 🚫 Alert
- **( ! ) DON'T REPOST THIS CODE / THIS PROJECT WITHOUT ANY CREDIT**
- **( ! ) DON'T SELL THIS PROJECT TO ANOTHER PERSON, BECAUSE THIS IS FREE TO USE**
- **( ! ) REPORT TO THIS GITHUB REPOSITORY ISSUES IF YOU FOUND SOME BUG**

