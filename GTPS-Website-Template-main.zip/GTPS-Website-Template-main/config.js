/* 
 -- READ THIS --

- You can change the server feature in index.html file and find the feature part / feature area
- You can change your server about in index.html file and find the about part / about us area

 -- CHANGE THE WEBSITE OPTION IN BELOW --
*/
let option = {
    server_name: "Your server name",
    server_description: "Your server Description",
    owner: [
        "Owner Server#0000",
        "Owner Server#0000"
    ],
    discord_invite_link: "Your permanent discord invite link",
    ip_address: "Your server ip address",
    host_for_android: "Your host link for android device"
}

